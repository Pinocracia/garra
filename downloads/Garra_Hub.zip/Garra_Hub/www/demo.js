/* Garra — modo demonstração (OBS e PC simulados, para testar sem nada instalado) */
'use strict';

class DemoObs extends Emitter {
  constructor() {
    super();
    this.status = 'idle'; this.detail = ''; this.wantMeters = false;
    const t = Date.now();
    this.m = {
      scenes: ['Começando', 'Conversa', 'Gameplay', 'Tela cheia', 'Intervalo', 'Encerramento'],
      program: 'Conversa', preview: 'Gameplay', studio: false,
      items: {
        'Começando': [['Fundo animado', true], ['Contagem regressiva', true], ['Música de espera', true], ['Logo', true]],
        'Conversa': [['Câmera', true], ['Moldura da câmera', true], ['Chat na tela', true], ['Alertas', true], ['Fundo', true]],
        'Gameplay': [['Captura de jogo', true], ['Câmera', true], ['Chat na tela', false], ['Alertas', true], ['Metas', true]],
        'Tela cheia': [['Captura de jogo', true], ['Alertas', true]],
        'Intervalo': [['Fundo animado', true], ['Volto já', true], ['Música de espera', true]],
        'Encerramento': [['Créditos', true], ['Redes sociais', true], ['Música de espera', true]]
      },
      inputs: [
        { name: 'Áudio do desktop', kind: 'wasapi_output_capture', mul: 0.5, muted: false },
        { name: 'Microfone', kind: 'wasapi_input_capture', mul: 0.89, muted: false },
        { name: 'Música de espera', kind: 'ffmpeg_source', mul: 0.25, muted: false },
        { name: 'Chat de voz', kind: 'wasapi_process_output_capture', mul: 0.6, muted: false },
        { name: 'Alertas', kind: 'browser_source', mul: 0.7, muted: true }
      ],
      stream: { active: true, start: t - (1 * 3600 + 23 * 60 + 41) * 1000, bytes: 0 },
      rec: { active: false, paused: false, start: 0 },
      replay: { active: true }, vcam: { active: false }
    };
    this.ids = {};
    let id = 1;
    Object.keys(this.m.items).forEach(s => { this.ids[s] = this.m.items[s].map(() => id++); });
  }
  setStatus(s, d) { this.status = s; this.detail = d || ''; this.emit('status', s, this.detail); }
  connect() {
    this.setStatus('connecting');
    setTimeout(() => { this.setStatus('ready'); this.emit('ready'); }, 350);
    clearInterval(this.iv);
    this.iv = setInterval(() => { if (this.wantMeters) this._meters(); this.m.stream.bytes += 67000; }, 90);
  }
  disconnect() { clearInterval(this.iv); this.setStatus('idle'); }
  reconnectNow() { }
  setMeters(on) { this.wantMeters = on; }
  _ev(type, data) { setTimeout(() => this.emit('event', type, data), 30); }
  _meters() {
    const tt = Date.now() / 1000;
    const inputs = this.m.inputs.map((i, k) => {
      let lvl = i.muted ? 0 : i.mul * (0.35 + 0.35 * Math.abs(Math.sin(tt * (1.3 + k * 0.7))) + 0.25 * Math.random());
      if (i.name === 'Microfone') lvl = i.muted ? 0 : (Math.sin(tt * 3) > 0.1 ? 0.55 + Math.random() * 0.4 : 0.03) * i.mul;
      return { inputName: i.name, inputLevelsMul: [[lvl * 0.7, lvl, lvl], [lvl * 0.65, lvl * 0.95, lvl]] };
    });
    this.emit('event', 'InputVolumeMeters', { inputs });
  }
  _input(n) { return this.m.inputs.find(i => i.name === n); }
  async request(type, d) {
    d = d || {};
    const m = this.m;
    await sleep(40);
    switch (type) {
      case 'GetSceneList':
        return { currentProgramSceneName: m.program, currentPreviewSceneName: m.studio ? m.preview : null, scenes: m.scenes.slice().reverse().map((n, i) => ({ sceneName: n, sceneIndex: i })) };
      case 'GetStudioModeEnabled': return { studioModeEnabled: m.studio };
      case 'SetStudioModeEnabled': m.studio = d.studioModeEnabled; this._ev('StudioModeStateChanged', { studioModeEnabled: m.studio }); return {};
      case 'GetCurrentPreviewScene': return { currentPreviewSceneName: m.preview };
      case 'SetCurrentProgramScene': m.program = d.sceneName; this._ev('CurrentProgramSceneChanged', { sceneName: m.program }); return {};
      case 'SetCurrentPreviewScene': m.preview = d.sceneName; this._ev('CurrentPreviewSceneChanged', { sceneName: m.preview }); return {};
      case 'TriggerStudioModeTransition': { const p = m.program; m.program = m.preview; m.preview = p; this._ev('CurrentProgramSceneChanged', { sceneName: m.program }); this._ev('CurrentPreviewSceneChanged', { sceneName: m.preview }); return {}; }
      case 'GetSceneItemList':
        return { sceneItems: (m.items[d.sceneName] || []).map((it, k) => ({ sceneItemId: this.ids[d.sceneName][k], sourceName: it[0], sceneItemEnabled: it[1], isGroup: false, sceneItemIndex: k })).reverse() };
      case 'SetSceneItemEnabled': {
        const k = this.ids[d.sceneName].indexOf(d.sceneItemId); m.items[d.sceneName][k][1] = d.sceneItemEnabled;
        this._ev('SceneItemEnableStateChanged', { sceneName: d.sceneName, sceneItemId: d.sceneItemId, sceneItemEnabled: d.sceneItemEnabled }); return {};
      }
      case 'GetStreamStatus': return { outputActive: m.stream.active, outputReconnecting: false, outputDuration: m.stream.active ? Date.now() - m.stream.start : 0, outputBytes: m.stream.bytes, outputCongestion: 0.02, outputSkippedFrames: 3, outputTotalFrames: 301230 };
      case 'StartStream': m.stream.active = true; m.stream.start = Date.now(); this._ev('StreamStateChanged', { outputActive: true, outputState: 'OBS_WEBSOCKET_OUTPUT_STARTED' }); return {};
      case 'StopStream': m.stream.active = false; this._ev('StreamStateChanged', { outputActive: false, outputState: 'OBS_WEBSOCKET_OUTPUT_STOPPED' }); return {};
      case 'GetRecordStatus': return { outputActive: m.rec.active, outputPaused: m.rec.paused, outputDuration: m.rec.active ? Date.now() - m.rec.start : 0 };
      case 'StartRecord': m.rec = { active: true, paused: false, start: Date.now() }; this._ev('RecordStateChanged', { outputActive: true, outputState: 'OBS_WEBSOCKET_OUTPUT_STARTED' }); return {};
      case 'StopRecord': m.rec.active = false; this._ev('RecordStateChanged', { outputActive: false, outputState: 'OBS_WEBSOCKET_OUTPUT_STOPPED' }); return { outputPath: 'C:/Videos/gravacao.mkv' };
      case 'PauseRecord': m.rec.paused = true; this._ev('RecordStateChanged', { outputActive: true, outputState: 'OBS_WEBSOCKET_OUTPUT_PAUSED' }); return {};
      case 'ResumeRecord': m.rec.paused = false; this._ev('RecordStateChanged', { outputActive: true, outputState: 'OBS_WEBSOCKET_OUTPUT_RESUMED' }); return {};
      case 'GetReplayBufferStatus': return { outputActive: m.replay.active };
      case 'StartReplayBuffer': m.replay.active = true; this._ev('ReplayBufferStateChanged', { outputActive: true }); return {};
      case 'SaveReplayBuffer': this._ev('ReplayBufferSaved', { savedReplayPath: 'C:/Videos/replay.mkv' }); return {};
      case 'GetVirtualCamStatus': return { outputActive: m.vcam.active };
      case 'ToggleVirtualCam': m.vcam.active = !m.vcam.active; this._ev('VirtualcamStateChanged', { outputActive: m.vcam.active }); return { outputActive: m.vcam.active };
      case 'GetStats': return { cpuUsage: 7 + Math.random() * 6, activeFps: 60, renderSkippedFrames: 0, renderTotalFrames: 100000, outputSkippedFrames: 3, outputTotalFrames: 301230, memoryUsage: 512 };
      case 'GetInputList': return { inputs: m.inputs.map(i => ({ inputName: i.name, inputKind: i.kind })).concat([{ inputName: 'Câmera', inputKind: 'dshow_input' }]) };
      case 'GetSpecialInputs': return { desktop1: 'Áudio do desktop', mic1: 'Microfone' };
      case 'GetInputVolume': { const i = this._input(d.inputName); if (!i) throw new Error('Sem áudio'); return { inputVolumeMul: i.mul, inputVolumeDb: i.mul > 0 ? 20 * Math.log10(i.mul) : -100 }; }
      case 'GetInputMute': { const i = this._input(d.inputName); if (!i) throw new Error('Sem áudio'); return { inputMuted: i.muted }; }
      case 'SetInputVolume': { const i = this._input(d.inputName); i.mul = d.inputVolumeMul; this._ev('InputVolumeChanged', { inputName: i.name, inputVolumeMul: i.mul, inputVolumeDb: i.mul > 0 ? 20 * Math.log10(i.mul) : -100 }); return {}; }
      case 'SetInputMute': { const i = this._input(d.inputName); i.muted = d.inputMuted; this._ev('InputMuteStateChanged', { inputName: i.name, inputMuted: i.muted }); return {}; }
      case 'ToggleInputMute': { const i = this._input(d.inputName); i.muted = !i.muted; this._ev('InputMuteStateChanged', { inputName: i.name, inputMuted: i.muted }); return { inputMuted: i.muted }; }
    }
    throw new Error('Não disponível no modo demonstração');
  }
}

class DemoHub extends Emitter {
  constructor() {
    super();
    this.status = 'none'; this.cfg = null; this.fast = false;
    this.state = {
      ok: true, pc: { name: 'PC-DEMO', wake: { mac: '00:1A:2B:3C:4D:5E', bcast: '192.168.0.255', ip: '192.168.0.10', wired: true } },
      out: { id: 'o1', name: 'Fone de ouvido (USB)', vol: 0.42, mute: false },
      in: { id: 'i1', name: 'Microfone (USB)', vol: 0.8, mute: false },
      outs: [{ id: 'o1', name: 'Fone de ouvido (USB)', def: true }, { id: 'o2', name: 'Alto-falantes (Realtek)', def: false }, { id: 'o3', name: 'Monitor (HDMI)', def: false }],
      ins: [{ id: 'i1', name: 'Microfone (USB)', def: true }, { id: 'i2', name: 'Microfone da webcam', def: false }],
      apps: [
        { key: '101', name: 'OBS Studio', vol: 1, mute: false },
        { key: '102', name: 'Jogo', vol: 0.55, mute: false },
        { key: '103', name: 'Música', vol: 0.3, mute: false },
        { key: '104', name: 'Chat de voz', vol: 0.75, mute: false },
        { key: '105', name: 'Navegador', vol: 0.6, mute: true },
        { key: 'sys', name: 'Sons do sistema', vol: 0.4, mute: false }
      ],
      media: { title: 'Lo-fi para live — Faixa 03', app: 'Música', playing: true },
      obs: { running: true }
    };
    this.launchers = [
      ['Neon Rally', 'steam'], ['Pixel Quest', 'steam'], ['Arena Zero', 'steam'], ['Skyline Drift', 'epic'],
      ['Night Shift', 'steam'], ['Farm Valley', 'epic'], ['Editor de vídeo', 'custom'], ['Discord', 'custom']
    ].map((x, i) => ({ id: 'd' + i, name: x[0], src: x[1], img: false }));
  }
  setStatus(s) { if (this.status !== s) { this.status = s; this.emit('status', s); } }
  configure(cfg) {
    this.cfg = cfg;
    clearInterval(this.iv);
    if (!cfg) { this.setStatus('none'); return; }
    this.setStatus('connecting');
    setTimeout(() => { this.setStatus('ready'); this.emit('state', this.state); }, 250);
    this.iv = setInterval(() => this.emit('state', this.state), 1500);
  }
  setFast() { }
  poll() { this.emit('state', this.state); }
  async cmd(o) {
    await sleep(60);
    const s = this.state;
    const tgt = o.target === 'out' ? s.out : o.target === 'in' ? s.in : s.apps.find(a => a.key === o.key);
    if (o.a === 'vol' && tgt) tgt.vol = o.v;
    else if (o.a === 'mute' && tgt) tgt.mute = !!o.v;
    else if (o.a === 'dev') {
      const list = o.flow === 'in' ? s.ins : s.outs;
      list.forEach(d => d.def = d.id === o.id);
      const d = list.find(x => x.id === o.id);
      if (o.flow === 'in') s.in = Object.assign({}, s.in, { id: d.id, name: d.name }); else s.out = Object.assign({}, s.out, { id: d.id, name: d.name });
    } else if (o.a === 'media') { if (o.k === 'play') s.media.playing = !s.media.playing; }
    this.emit('state', s);
    return { ok: true };
  }
  async get(path) {
    await sleep(120);
    if (path === '/api/launchers') return { ok: true, items: this.launchers };
    if (path === '/api/obs') return { ok: true, found: true, enabled: true, port: 4455, auth: true, password: 'demo' };
    return { ok: true };
  }
  imgUrl() { return ''; }
}

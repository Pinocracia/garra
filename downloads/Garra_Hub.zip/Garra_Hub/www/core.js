/* Garra — núcleo: configuração, rede, cliente do OBS (WebSocket v5) e cliente do Garra Hub */
'use strict';

const APP = {
  name: 'Garra',
  version: '0.9.3 beta',
  hubPort: 8650,
  obsPort: 4455,
  supportEmail: '',            // ex.: 'contato@seudominio.com' (aparece em Ajustes > Enviar feedback)
  hubDownloadUrl: 'https://pinocracia.github.io/garra/#instalar',          // link de download do Garra Hub (Drive/GitHub). Vazio = mostra instruções.
  proUrl: 'https://pinocracia.github.io/garra/#preco',  // página de compra no site (preço e botão Comprar)
  proPrice: '5,00 €',            // preço mostrado no app
  proPriceNote: 'Pagamento único, licença vitalícia',
  trialDays: 7,
  privacyUrl: 'privacy.html'
};

/* ---------------- utilidades ---------------- */
class Emitter {
  constructor() { this._h = {}; }
  on(ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); return () => this.off(ev, fn); }
  off(ev, fn) { const a = this._h[ev]; if (a) this._h[ev] = a.filter(f => f !== fn); }
  emit(ev, ...args) { (this._h[ev] || []).slice().forEach(fn => { try { fn(...args); } catch (e) { console.error(e); } }); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------------- configuração salva no aparelho ---------------- */
const Cfg = {
  key: 'garra.v1',
  data: null,
  defaults() {
    return {
      onboarded: false,
      hub: null,                                   // {host, port, token, name}
      obs: { host: '', port: 4455, pass: '', fromHub: true },
      prefs: { haptics: true, awake: true, confirmStop: true, meters: true, size: 'm', mic: '' },
      favs: [],
      license: '',                                 // chave do Garra Pro
      trialStart: 0, lastSeen: 0                   // teste grátis
    };
  },
  load() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(this.key) || 'null'); } catch (e) { d = null; }
    const def = this.defaults();
    this.data = Object.assign(def, d || {});
    this.data.obs = Object.assign(def.obs, (d && d.obs) || {});
    this.data.prefs = Object.assign(def.prefs, (d && d.prefs) || {});
    return this.data;
  },
  save() { try { localStorage.setItem(this.key, JSON.stringify(this.data)); } catch (e) { } }
};

/* ---------------- ponte com o app Android (quando existe) ---------------- */
const Native = (function () {
  const n = window.GarraNative;
  if (!n) return null;
  let seq = 0; const cbs = {};
  window.__garraCb = function (id, json) {
    const cb = cbs[id]; if (!cb) return; delete cbs[id];
    let v = null; try { v = JSON.parse(json); } catch (e) { v = null; }
    cb(v);
  };
  function call(fn, ...args) {
    return new Promise(res => {
      const id = 'n' + (++seq); cbs[id] = res;
      try { n[fn](id, ...args); } catch (e) { delete cbs[id]; res(null); }
    });
  }
  const safe = (f, d) => { try { return f(); } catch (e) { return d; } };
  return {
    http: (method, url, body, timeout) => call('http', method, url, body || '', timeout || 6000),
    scan: (ports, timeout) => call('scan', ports.join(','), timeout || 450),
    wake: (mac, bcast) => n.wake ? call('wake', mac, bcast || '') : Promise.resolve(null),
    canWake: () => !!n.wake,
    haptic: k => safe(() => n.haptic(k)),
    keepAwake: v => safe(() => n.keepAwake(!!v)),
    open: u => safe(() => n.openExternal(u)),
    version: () => safe(() => n.version(), ''),
    localIp: () => safe(() => n.localIp(), ''),
    device: () => safe(() => n.deviceName(), 'Android')
  };
})();

function openExternal(url) {
  if (Native) Native.open(url); else window.open(url, '_blank', 'noopener');
}

/* ---------------- HTTP (nativo no Android, fetch no navegador) ---------------- */
async function httpJson(method, url, body, timeout) {
  timeout = timeout || 6000;
  const payload = body == null ? '' : (typeof body === 'string' ? body : JSON.stringify(body));
  let r;
  const sameOrigin = location.protocol.startsWith('http') && url.indexOf(location.origin + '/') === 0;
  if (Native && !sameOrigin) {
    r = await Native.http(method, url, payload, timeout);
    if (!r || r.error) throw new Error((r && r.error) || 'Sem resposta');
  } else {
    const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const t = setTimeout(() => ctl && ctl.abort(), timeout);
    try {
      const res = await fetch(url, {
        method, cache: 'no-store', signal: ctl ? ctl.signal : undefined,
        body: method === 'GET' ? undefined : payload,
        headers: method === 'GET' ? undefined : { 'Content-Type': 'text/plain' }
      });
      r = { status: res.status, body: await res.text() };
    } catch (e) {
      throw new Error(e && e.name === 'AbortError' ? 'Tempo esgotado' : 'Sem conexão');
    } finally { clearTimeout(t); }
  }
  let j = null; try { j = JSON.parse(r.body); } catch (e) { j = null; }
  if (r.status === 401 || r.status === 403) { const e = new Error((j && j.error) || 'Não autorizado'); e.code = r.status; e.data = j; throw e; }
  if (r.status >= 400) { const e = new Error((j && j.error) || ('Erro ' + r.status)); e.code = r.status; throw e; }
  if (j == null) throw new Error('Resposta inválida');
  return j;
}

/* ---------------- cliente do OBS (obs-websocket 5.x) ---------------- */
async function obsAuthString(password, salt, challenge) {
  async function b64sha(str) {
    if (window.crypto && crypto.subtle && window.isSecureContext) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
      let s = ''; new Uint8Array(buf).forEach(b => s += String.fromCharCode(b));
      return btoa(s);
    }
    return sha256b64(str);
  }
  const secret = await b64sha(password + salt);
  return b64sha(secret + challenge);
}

class ObsClient extends Emitter {
  constructor() {
    super();
    this.ws = null; this.status = 'idle'; this.detail = '';
    this.pending = new Map(); this.seq = 0; this.retry = 0;
    this.wantMeters = false; this.url = ''; this.password = '';
  }
  setStatus(s, detail) {
    this.status = s; this.detail = detail || '';
    this.emit('status', s, this.detail);
  }
  connect(host, port, password) {
    this.disconnect(true);
    if (!host) { this.setStatus('idle'); return; }
    this.url = 'ws://' + host + ':' + (port || 4455);
    this.password = password || '';
    this.manual = false; this.retry = 0;
    this._open();
  }
  disconnect(silent) {
    this.manual = true; clearTimeout(this.rt); clearTimeout(this.ct);
    if (this.ws) { try { this.ws.close(); } catch (e) { } this.ws = null; }
    if (!silent) this.setStatus('idle');
  }
  reconnectNow() { if (this.url && this.status !== 'ready') { clearTimeout(this.rt); this.manual = false; this._open(); } }
  subs() { return 2047 | (this.wantMeters ? 65536 : 0); }
  setMeters(on) {
    if (this.wantMeters === on) return;
    this.wantMeters = on;
    if (this.status === 'ready') this._send(3, { eventSubscriptions: this.subs() });
  }
  _send(op, d) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op, d })); }
  _open() {
    clearTimeout(this.rt); clearTimeout(this.ct);
    this.setStatus('connecting');
    let ws;
    try { ws = new WebSocket(this.url, 'obswebsocket.json'); }
    catch (e) { this.setStatus('error', 'Endereço inválido'); return; }
    this.ws = ws;
    ws.onmessage = ev => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } this._msg(m); };
    ws.onclose = ev => { if (this.ws === ws) this._closed(ev); };
    ws.onerror = () => { };
    this.ct = setTimeout(() => { if (this.ws === ws && this.status === 'connecting') { try { ws.close(); } catch (e) { } } }, 7000);
  }
  async _msg(m) {
    const d = m.d || {};
    if (m.op === 0) {
      const ident = { rpcVersion: 1, eventSubscriptions: this.subs() };
      if (d.authentication) {
        if (!this.password) { this.authProblem = 'need'; this.manual = true; try { this.ws.close(); } catch (e) { } this.setStatus('auth', 'O OBS pede senha'); return; }
        ident.authentication = await obsAuthString(this.password, d.authentication.salt, d.authentication.challenge);
      }
      this._send(1, ident);
    } else if (m.op === 2) {
      clearTimeout(this.ct); this.retry = 0;
      if (this.status === 'ready') return;   // resposta a um Reidentify (ex.: ligar medidores)
      this.setStatus('ready');
      this.emit('ready');
    } else if (m.op === 5) {
      this.emit('event', d.eventType, d.eventData || {});
    } else if (m.op === 7) {
      const p = this.pending.get(d.requestId);
      if (!p) return;
      this.pending.delete(d.requestId); clearTimeout(p.t);
      if (d.requestStatus && d.requestStatus.result) p.res(d.responseData || {});
      else { const e = new Error((d.requestStatus && d.requestStatus.comment) || 'Falhou'); e.code = d.requestStatus && d.requestStatus.code; p.rej(e); }
    }
  }
  _closed(ev) {
    clearTimeout(this.ct);
    this.ws = null;
    this.pending.forEach(p => { clearTimeout(p.t); p.rej(new Error('Desconectado')); });
    this.pending.clear();
    if (this.status === 'ready') this.emit('lost');
    if (ev && ev.code === 4009) { this.manual = true; this.setStatus('auth', 'Senha do OBS incorreta'); return; }
    if (this.manual) { if (this.status !== 'auth') this.setStatus('idle'); return; }
    const delay = Math.min(12000, Math.round(1200 * Math.pow(1.5, this.retry++)));
    this.setStatus('offline', 'OBS não respondeu');
    this.rt = setTimeout(() => this._open(), delay);
  }
  request(type, data, timeout) {
    return new Promise((res, rej) => {
      if (!this.ws || this.status !== 'ready') { rej(new Error('OBS desconectado')); return; }
      const id = 'r' + (++this.seq);
      const t = setTimeout(() => { this.pending.delete(id); rej(new Error('O OBS demorou para responder')); }, timeout || 8000);
      this.pending.set(id, { res, rej, t });
      this._send(6, { requestType: type, requestId: id, requestData: data || {} });
    });
  }
}

/* ---------------- cliente do Garra Hub (app do Windows) ---------------- */
class HubClient extends Emitter {
  constructor() {
    super();
    this.cfg = null; this.status = 'none'; this.state = null; this.fails = 0; this.fast = false; this.timer = 0;
  }
  setStatus(s) { if (this.status !== s) { this.status = s; this.emit('status', s); } }
  base(cfg) { cfg = cfg || this.cfg; return 'http://' + cfg.host + ':' + (cfg.port || APP.hubPort); }
  url(path, q, cfg) {
    cfg = cfg || this.cfg;
    const p = new URLSearchParams(q || {});
    if (cfg && cfg.token) p.set('t', cfg.token);
    const qs = p.toString();
    return this.base(cfg) + path + (qs ? '?' + qs : '');
  }
  configure(cfg) {
    clearTimeout(this.timer);
    this.cfg = cfg && cfg.host ? cfg : null;
    this.state = null; this.fails = 0;
    if (this.cfg) { this.setStatus('connecting'); this.poll(); } else this.setStatus('none');
  }
  setFast(on) { if (this.fast !== on) { this.fast = on; if (on && this.cfg) this.poll(); } }
  interval() { if (document.hidden) return 15000; return this.fast ? 1200 : 5000; }
  async poll() {
    clearTimeout(this.timer);
    if (!this.cfg) return;
    const cfg = this.cfg;
    try {
      const j = await httpJson('GET', this.url('/api/state'), null, 4500);
      if (cfg !== this.cfg) return;
      if (j && j.ok) { this.state = j; this.fails = 0; this.setStatus('ready'); this.emit('state', j); }
    } catch (e) {
      if (cfg !== this.cfg) return;
      if (e.code === 401 || e.code === 403) { this.setStatus('unpaired'); this.timer = setTimeout(() => this.poll(), 8000); return; }
      this.fails++;
      if (this.fails >= 2) this.setStatus('offline');
      if (this.fails === 3 || (this.fails > 3 && this.fails % 6 === 0)) this.seek();
    }
    this.timer = setTimeout(() => this.poll(), this.status === 'offline' ? Math.min(15000, 3000 * this.fails) : this.interval());
  }
  /** O PC pode ter trocado de IP (roteador): procura o mesmo Hub na rede e testa o pareamento salvo. */
  async seek() {
    if (this.seeking || !Native || !this.cfg || !this.cfg.token) return;
    this.seeking = true;
    const cfg = this.cfg;
    try {
      const r = await discover();
      for (const x of r.hubs) {
        if (x.host === cfg.host) continue;
        try {
          const j = await httpJson('GET', this.url('/api/state', null, { host: x.host, port: x.port, token: cfg.token }), null, 3500);
          if (j && j.ok && cfg === this.cfg) {
            cfg.host = x.host; cfg.port = x.port; Cfg.save();
            this.emit('moved', x.host);
            this.fails = 0; this.poll();
            break;
          }
        } catch (e) { }
      }
    } finally { this.seeking = false; }
  }
  async cmd(o) {
    if (!this.cfg) throw new Error('PC não conectado');
    const j = await httpJson('POST', this.url('/api/cmd'), o, 5000);
    if (!j.ok) throw new Error(j.error || 'Não deu certo');
    return j;
  }
  get(path, q) { return httpJson('GET', this.url(path, q), null, 6000); }
  imgUrl(path, q) { return this.url(path, q); }
  static hello(host, port) { return httpJson('GET', 'http://' + host + ':' + (port || APP.hubPort) + '/api/hello', null, 2500); }
  static pairReq(host, port, device) { return httpJson('POST', 'http://' + host + ':' + (port || APP.hubPort) + '/api/pairreq', { device }, 6000); }
  static pairPoll(host, port, id) { return httpJson('GET', 'http://' + host + ':' + (port || APP.hubPort) + '/api/pairreq?id=' + encodeURIComponent(id), null, 5000); }
  static pair(host, port, pin, device) {
    return httpJson('POST', 'http://' + host + ':' + (port || APP.hubPort) + '/api/pair', { pin, device }, 6000);
  }
}

/* ---------------- busca automática na rede ---------------- */
async function discover() {
  const out = { hubs: [], obs: [] };
  if (!Native) return out;
  const found = (await Native.scan([APP.hubPort, APP.obsPort], 500)) || [];
  const hubIps = found.filter(f => f.port === APP.hubPort).map(f => f.ip);
  const obsIps = found.filter(f => f.port === APP.obsPort).map(f => f.ip);
  const hellos = await Promise.all(hubIps.map(ip => HubClient.hello(ip, APP.hubPort).then(j => ({ ip, j })).catch(() => null)));
  hellos.forEach(x => { if (x && x.j && x.j.app === 'garra-hub') out.hubs.push({ host: x.ip, port: APP.hubPort, name: x.j.name || x.ip, version: x.j.v, approve: !!x.j.approve }); });
  out.obs = obsIps.map(ip => ({ host: ip, port: APP.obsPort, hasHub: hubIps.indexOf(ip) >= 0 }));
  return out;
}

/* ================= Garra Pro ================= */
/* Ed25519 + SHA-512 em JavaScript puro (sem dependências). Usado pelo Garra para conferir chaves Pro. */
var GarraSig = (function () {
  'use strict';
  var M64 = (1n << 64n) - 1n;
  var K = ['428a2f98d728ae22','7137449123ef65cd','b5c0fbcfec4d3b2f','e9b5dba58189dbbc','3956c25bf348b538','59f111f1b605d019','923f82a4af194f9b','ab1c5ed5da6d8118','d807aa98a3030242','12835b0145706fbe','243185be4ee4b28c','550c7dc3d5ffb4e2','72be5d74f27b896f','80deb1fe3b1696b1','9bdc06a725c71235','c19bf174cf692694','e49b69c19ef14ad2','efbe4786384f25e3','0fc19dc68b8cd5b5','240ca1cc77ac9c65','2de92c6f592b0275','4a7484aa6ea6e483','5cb0a9dcbd41fbd4','76f988da831153b5','983e5152ee66dfab','a831c66d2db43210','b00327c898fb213f','bf597fc7beef0ee4','c6e00bf33da88fc2','d5a79147930aa725','06ca6351e003826f','142929670a0e6e70','27b70a8546d22ffc','2e1b21385c26c926','4d2c6dfc5ac42aed','53380d139d95b3df','650a73548baf63de','766a0abb3c77b2a8','81c2c92e47edaee6','92722c851482353b','a2bfe8a14cf10364','a81a664bbc423001','c24b8b70d0f89791','c76c51a30654be30','d192e819d6ef5218','d69906245565a910','f40e35855771202a','106aa07032bbd1b8','19a4c116b8d2d0c8','1e376c085141ab53','2748774cdf8eeb99','34b0bcb5e19b48a8','391c0cb3c5c95a63','4ed8aa4ae3418acb','5b9cca4f7763e373','682e6ff3d6b2b8a3','748f82ee5defb2fc','78a5636f43172f60','84c87814a1f0ab72','8cc702081a6439ec','90befffa23631e28','a4506cebde82bde9','bef9a3f7b2c67915','c67178f2e372532b','ca273eceea26619c','d186b8c721c0c207','eada7dd6cde0eb1e','f57d4f7fee6ed178','06f067aa72176fba','0a637dc5a2c898a6','113f9804bef90dae','1b710b35131c471b','28db77f523047d84','32caab7b40c72493','3c9ebe0a15c9bebc','431d67c49c100d4c','4cc5d4becb3e42b6','597f299cfc657e2a','5fcb6fab3ad6faec','6c44198c4a475817'].map(function (x) { return BigInt('0x' + x); });
  function rotr(x, n) { return ((x >> n) | (x << (64n - n))) & M64; }
  function sha512(bytes) {
    var H = ['6a09e667f3bcc908','bb67ae8584caa73b','3c6ef372fe94f82b','a54ff53a5f1d36f1','510e527fade682d1','9b05688c2b3e6c1f','1f83d9abfb41bd6b','5be0cd19137e2179'].map(function (x) { return BigInt('0x' + x); });
    var len = bytes.length, padLen = ((len + 17 + 127) >> 7) << 7;
    var m = new Uint8Array(padLen); m.set(bytes); m[len] = 0x80;
    var bits = BigInt(len) * 8n;
    for (var i = 0; i < 16; i++) m[padLen - 1 - i] = Number((bits >> BigInt(8 * i)) & 255n);
    var W = new Array(80);
    for (var off = 0; off < padLen; off += 128) {
      for (var t = 0; t < 16; t++) { var w = 0n; for (var b = 0; b < 8; b++) w = (w << 8n) | BigInt(m[off + t * 8 + b]); W[t] = w; }
      for (t = 16; t < 80; t++) {
        var s0 = rotr(W[t - 15], 1n) ^ rotr(W[t - 15], 8n) ^ (W[t - 15] >> 7n);
        var s1 = rotr(W[t - 2], 19n) ^ rotr(W[t - 2], 61n) ^ (W[t - 2] >> 6n);
        W[t] = (W[t - 16] + s0 + W[t - 7] + s1) & M64;
      }
      var a = H[0], bb = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 80; t++) {
        var S1 = rotr(e, 14n) ^ rotr(e, 18n) ^ rotr(e, 41n);
        var ch = (e & f) ^ (~e & M64 & g);
        var T1 = (h + S1 + ch + K[t] + W[t]) & M64;
        var S0 = rotr(a, 28n) ^ rotr(a, 34n) ^ rotr(a, 39n);
        var mj = (a & bb) ^ (a & c) ^ (bb & c);
        var T2 = (S0 + mj) & M64;
        h = g; g = f; f = e; e = (d + T1) & M64; d = c; c = bb; bb = a; a = (T1 + T2) & M64;
      }
      H[0] = (H[0] + a) & M64; H[1] = (H[1] + bb) & M64; H[2] = (H[2] + c) & M64; H[3] = (H[3] + d) & M64;
      H[4] = (H[4] + e) & M64; H[5] = (H[5] + f) & M64; H[6] = (H[6] + g) & M64; H[7] = (H[7] + h) & M64;
    }
    var out = new Uint8Array(64);
    for (i = 0; i < 8; i++) for (b = 0; b < 8; b++) out[i * 8 + b] = Number((H[i] >> BigInt(56 - 8 * b)) & 255n);
    return out;
  }
  // ---- curva ----
  var P = (1n << 255n) - 19n;
  var L = (1n << 252n) + 27742317777372353535851937790883648493n;
  function mod(a, m) { m = m || P; var r = a % m; return r >= 0n ? r : r + m; }
  function pow(b, e, m) { m = m || P; var r = 1n; b = mod(b, m); while (e > 0n) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; }
  function inv(a) { return pow(a, P - 2n); }
  var D = mod(-121665n * inv(121666n));
  var I = pow(2n, (P - 1n) / 4n);
  var Gy = mod(4n * inv(5n));
  function recoverX(y, sign) {
    var y2 = y * y % P;
    var x2 = mod((y2 - 1n) * inv(D * y2 + 1n));
    if (x2 === 0n) { if (sign) return null; return 0n; }
    var x = pow(x2, (P + 3n) / 8n);
    if (mod(x * x - x2) !== 0n) x = x * I % P;
    if (mod(x * x - x2) !== 0n) return null;
    if (Number(x & 1n) !== sign) x = P - x;
    return x;
  }
  var Gx = recoverX(Gy, 0);
  var G = [Gx, Gy, 1n, Gx * Gy % P];
  function add(p, q) {
    var A = mod((p[1] - p[0]) * (q[1] - q[0])), B = mod((p[1] + p[0]) * (q[1] + q[0]));
    var C = mod(2n * p[3] * q[3] * D), Dd = mod(2n * p[2] * q[2]);
    var E = B - A, F = Dd - C, Gg = Dd + C, H = B + A;
    return [mod(E * F), mod(Gg * H), mod(F * Gg), mod(E * H)];
  }
  function mul(s, p) { var q = [0n, 1n, 1n, 0n]; while (s > 0n) { if (s & 1n) q = add(q, p); p = add(p, p); s >>= 1n; } return q; }
  function eq(p, q) { return mod(p[0] * q[2] - q[0] * p[2]) === 0n && mod(p[1] * q[2] - q[1] * p[2]) === 0n; }
  function le2n(b) { var n = 0n; for (var i = b.length - 1; i >= 0; i--) n = (n << 8n) | BigInt(b[i]); return n; }
  function n2le(n, len) { var b = new Uint8Array(len); for (var i = 0; i < len; i++) { b[i] = Number(n & 255n); n >>= 8n; } return b; }
  function encode(p) { var zi = inv(p[2]), x = p[0] * zi % P, y = p[1] * zi % P; var b = n2le(y, 32); b[31] |= Number(x & 1n) << 7; return b; }
  function decode(b) {
    if (b.length !== 32) return null;
    var c = Uint8Array.from(b); var sign = c[31] >> 7; c[31] &= 0x7f;
    var y = le2n(c); if (y >= P) return null;
    var x = recoverX(y, sign); if (x === null) return null;
    return [x, y, 1n, x * y % P];
  }
  function cat() { var n = 0, i; for (i = 0; i < arguments.length; i++) n += arguments[i].length; var o = new Uint8Array(n), k = 0; for (i = 0; i < arguments.length; i++) { o.set(arguments[i], k); k += arguments[i].length; } return o; }
  function expand(seed) { var h = sha512(seed); var a = h.slice(0, 32); a[0] &= 248; a[31] &= 127; a[31] |= 64; return { a: le2n(a), prefix: h.slice(32) }; }
  function publicKey(seed) { return encode(mul(expand(seed).a, G)); }
  function sign(msg, seed) {
    var ex = expand(seed), A = encode(mul(ex.a, G));
    var r = mod(le2n(sha512(cat(ex.prefix, msg))), L);
    var R = encode(mul(r, G));
    var k = mod(le2n(sha512(cat(R, A, msg))), L);
    return cat(R, n2le(mod(r + k * ex.a, L), 32));
  }
  function verify(sig, msg, pub) {
    try {
      if (sig.length !== 64 || pub.length !== 32) return false;
      var A = decode(pub), R = decode(sig.slice(0, 32)); if (!A || !R) return false;
      var s = le2n(sig.slice(32)); if (s >= L) return false;
      var k = mod(le2n(sha512(cat(sig.slice(0, 32), pub, msg))), L);
      return eq(mul(s, G), add(R, mul(k, A)));
    } catch (e) { return false; }
  }
  return { sha512: sha512, publicKey: publicKey, sign: sign, verify: verify };
})();

/* Chaves do Garra Pro: GARRA-<base64url(dados + assinatura Ed25519)>. Só quem tem o segredo cria chaves; o app só confere. */
var GarraLicense = (function () {
  'use strict';
  var DOMAIN = 'GARRA-PRO\u0000';
  var EPOCH = Date.UTC(2026, 0, 1);
  function utf8(s) { return new TextEncoder().encode(s); }
  function b64u(bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(str) { str = str.replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; var s = atob(str), o = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; }
  function hex(h) { var o = new Uint8Array(h.length / 2); for (var i = 0; i < o.length; i++) o[i] = parseInt(h.substr(i * 2, 2), 16); return o; }
  function msgOf(payload) { var d = utf8(DOMAIN), m = new Uint8Array(d.length + payload.length); m.set(d); m.set(payload, d.length); return m; }
  function clean(str) { return String(str || '').replace(/\s+/g, '').replace(/^garra-/i, ''); }

  function parse(str, pubHex, revoked) {
    try {
      var raw = unb64u(clean(str));
      if (raw.length < 8 + 64 || raw[0] !== 1) return null;
      var payload = raw.slice(0, raw.length - 64), sig = raw.slice(raw.length - 64);
      if (!GarraSig.verify(sig, msgOf(payload), hex(pubHex))) return null;
      var serial = ((payload[1] << 24) >>> 0) + (payload[2] << 16) + (payload[3] << 8) + payload[4];
      if (revoked && revoked.indexOf(serial) >= 0) return null;
      var day = (payload[5] << 8) + payload[6];
      return {
        serial: serial,
        id: ('0000000' + serial.toString(16).toUpperCase()).slice(-8),
        date: new Date(EPOCH + day * 86400000),
        founder: !!(payload[7] & 1),
        name: new TextDecoder().decode(payload.slice(8))
      };
    } catch (e) { return null; }
  }

  function make(seedHex, name, founder) {
    var nm = utf8(String(name || '').trim()).slice(0, 40);
    while (nm.length && (nm[nm.length - 1] & 0xC0) === 0x80) nm = nm.slice(0, nm.length - 1); // não corta letra acentuada no meio
    if (nm.length && nm[nm.length - 1] >= 0xC0) nm = nm.slice(0, nm.length - 1);
    var payload = new Uint8Array(8 + nm.length);
    var rnd = new Uint8Array(4); crypto.getRandomValues(rnd);
    var day = Math.max(0, Math.floor((Date.now() - EPOCH) / 86400000));
    payload[0] = 1; payload.set(rnd, 1); payload[5] = day >> 8; payload[6] = day & 255; payload[7] = founder ? 1 : 0; payload.set(nm, 8);
    var sig = GarraSig.sign(msgOf(payload), hex(seedHex));
    var all = new Uint8Array(payload.length + 64); all.set(payload); all.set(sig, payload.length);
    return 'GARRA-' + b64u(all);
  }
  return { parse: parse, make: make };
})();

const Pro = {
  pub: '041b40cc5766ed9733711256d73f431ec7fe81343efe24921ce181810a58cba3',     // chave pública: só confere. A chave secreta fica no Gerador de Chaves, no PC do Marco.
  revoked: [],   // números de série de chaves bloqueadas (ex.: 0xA8E9FA34)
  info: null,
  load(str) { this.info = str ? GarraLicense.parse(str, this.pub, this.revoked) : null; return this.info; },
  activate(str) {
    const info = GarraLicense.parse(str, this.pub, this.revoked);
    if (!info) return null;
    Cfg.data.license = String(str).replace(/\s+/g, ''); Cfg.save();
    this.info = info; return info;
  },
  remove() { Cfg.data.license = ''; Cfg.save(); this.info = null; },
  /* ---- teste grátis de 7 dias ---- */
  now() {
    // não deixa voltar o relógio do aparelho para ganhar dias
    const d = Cfg.data, t = Date.now();
    if (!d.trialStart) { d.trialStart = t; d.lastSeen = t; Cfg.save(); }
    if (t > (d.lastSeen || 0)) { d.lastSeen = t; Cfg.save(); }
    return Math.max(t, d.lastSeen || 0);
  },
  trialLeft() { return Math.max(0, Cfg.data.trialStart + APP.trialDays * 86400000 - this.now()); },
  trialDaysLeft() { return Math.ceil(this.trialLeft() / 86400000); },
  status() { return this.info ? 'licensed' : this.trialLeft() > 0 ? 'trial' : 'expired'; }
};
